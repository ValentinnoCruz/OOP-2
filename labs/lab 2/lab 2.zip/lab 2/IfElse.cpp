

#include <iostream>

using namespace std;

int main()
{
	int n;
	cout << "input your value" << endl;
	cin >> n; {

	if (n % 2 == 0) {

		cout << "EVEN" << endl;

	}
	else {
		
		cout << "ODD" << endl;
	}

	}
}